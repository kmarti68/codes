// Case 6: Find the Largest Number (function + loop + array)
//
// Task: Write a function findLargest(numbers) that returns the biggest
// number in the array.
//
// Do NOT use Math.max. Practice with a loop instead.
// Hint: start with the first item, then compare it with each other item.

function findLargest(numbers) {
  // TODO: loop through the array and keep track of the largest number
}

// ---- Check your work (do not change) ----
console.log(findLargest([4, 9, 2, 7]));      // expected: 9
console.log(findLargest([-5, -2, -9]));      // expected: -2
console.log(findLargest([100]));             // expected: 100
