// Case 8: Student Report (function that creates and returns an object)
//
// Task: Write a function makeReport(name, scores) that creates an object
// and returns it. The object should have:
//   name     -> the student's name
//   average  -> the average of the scores
//   passed   -> true if the average is 60 or higher, otherwise false

function makeReport(name, scores) {
  // TODO: 1. add up the scores with a loop
  //       2. calculate the average
  //       3. create an object with name, average, and passed
  //       4. return the object
}

// ---- Check your work (do not change) ----
console.log(makeReport("Ann", [90, 80, 70]));
// expected: { name: 'Ann', average: 80, passed: true }

console.log(makeReport("Ben", [50, 40, 60]));
// expected: { name: 'Ben', average: 50, passed: false }
