// Case 5: Temperature Converter (functions)
//
// Task: Write two functions.
//   celsiusToFahrenheit(c)  ->  c * 9 / 5 + 32
//   fahrenheitToCelsius(f)  ->  (f - 32) * 5 / 9

function celsiusToFahrenheit(c) {
  // TODO: return the converted value
}

function fahrenheitToCelsius(f) {
  // TODO: return the converted value
}

// ---- Check your work (do not change) ----
console.log(celsiusToFahrenheit(0));   // expected: 32
console.log(celsiusToFahrenheit(100)); // expected: 212
console.log(fahrenheitToCelsius(32));  // expected: 0
console.log(fahrenheitToCelsius(212)); // expected: 100
